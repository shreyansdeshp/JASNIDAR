"""End-to-end test of the data prep scripts on small synthetic data.

    python tests/test_data_prep.py

Builds a fake VisDrone folder and a fake VOC (HERIDAL-style) folder, runs the
scripts, and checks that labels land where they should. It does not need the
real datasets. Passing it does NOT prove the real downloads have this format;
run data_prep/inspect_dataset.py on those first.
"""
import subprocess
import sys
import tempfile
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
PREP = ROOT / "data_prep"
SCALE = 1.5


def run(script, *args):
    r = subprocess.run([sys.executable, str(PREP / script), *map(str, args)], capture_output=True, text=True)
    assert r.returncode == 0, f"{script} failed:\n{r.stdout}\n{r.stderr}"
    return r.stdout


def close(a, b, tol=1e-3):
    return abs(a - b) <= tol


def read_label(path):
    return [tuple(float(v) for v in line.split()[1:]) for line in path.read_text().splitlines() if line.strip()]


def test_visdrone(tmp):
    src = tmp / "vd" / "VisDrone-train"
    (src / "images").mkdir(parents=True)
    (src / "annotations").mkdir()
    anns = {
        "0000001": ["100,200,40,80,1,1,0,0",     # pedestrian: keep
                    "500,500,30,70,1,2,0,0",     # people: keep
                    "700,300,100,50,1,4,0,0",    # car: drop
                    "0,0,200,200,0,0,0,0",       # ignored region: drop
                    "1000,900,50,90,0,1,0,0"],   # score 0: drop
        "0000002": ["700,300,100,50,1,4,0,0"],   # only a car: empty image
        "0000003": ["1900,1000,60,100,1,1,0,0"],  # runs off the image edge: clip
    }
    for stem, lines in anns.items():
        Image.new("RGB", (1920, 1080), (90, 120, 90)).save(src / "images" / f"{stem}.jpg")
        (src / "annotations" / f"{stem}.txt").write_text("\n".join(lines) + "\n")

    out = tmp / "visdrone"
    run("convert_visdrone.py", "--src", src, "--dst", out, "--split", "train", "--empty-ratio", "1.0")
    lbl = out / "labels" / "train"
    a = read_label(lbl / "0000001.txt")
    assert len(a) == 2, a
    assert close(a[0][0], 120 / 1920) and close(a[0][1], 240 / 1080) and close(a[0][2], 40 / 1920) and close(a[0][3], 80 / 1080)
    assert (lbl / "0000002.txt").read_text() == "", "empty image should be kept as a negative"
    c = read_label(lbl / "0000003.txt")
    assert len(c) == 1 and close(c[0][2], 20 / 1920) and close(c[0][3], 80 / 1080), c  # clipped to the image

    out0 = tmp / "visdrone0"
    run("convert_visdrone.py", "--src", src, "--dst", out0, "--split", "train", "--empty-ratio", "0")
    assert not (out0 / "labels" / "train" / "0000002.txt").exists(), "empty-ratio 0 should drop empty images"
    print("visdrone: ok")


def test_heridal(tmp):
    imgs = tmp / "h" / "images"
    imgs.mkdir(parents=True)
    # original-pixel boxes (x1, y1, x2, y2) on a 4000 x 3000 image
    objs = [(1000, 1000, 1060, 1100),   # fully inside one tile
            (360, 500, 380, 560),       # sits in the overlap of two tiles -> appears twice
            (3940, 2900, 4000, 3000),   # touches the bottom-right corner
            (420, 67, 466, 133)]        # cut by a tile edge: partly in tile 0, whole in the next
    Image.new("RGB", (4000, 3000), (110, 130, 100)).save(imgs / "img_a.jpg")
    Image.new("RGB", (4000, 3000), (110, 130, 100)).save(imgs / "img_b.jpg")
    xml = ["<annotation><size><width>100</width><height>100</height></size>"]  # wrong size on purpose
    for x1, y1, x2, y2 in objs:
        xml.append(f"<object><name>human</name><bndbox><xmin>{x1}</xmin><ymin>{y1}</ymin>"
                   f"<xmax>{x2}</xmax><ymax>{y2}</ymax></bndbox></object>")
    xml.append("</annotation>")
    (imgs / "img_a.xml").write_text("".join(xml))
    (imgs / "img_b.xml").write_text("<annotation><size><width>4000</width><height>3000</height></size></annotation>")

    labels = tmp / "h_labels"
    run("voc_to_yolo.py", "--src", imgs, "--dst", labels)
    la = read_label(labels / "img_a.txt")
    assert len(la) == 4
    assert close(la[0][0], 1030 / 4000) and close(la[0][1], 1050 / 3000), "image size must come from the real image, not the xml"
    assert (labels / "img_b.txt").read_text() == ""

    ds = tmp / "heridal"
    out = run("tile_dataset.py", "--images", imgs, "--labels", labels, "--dst", ds,
              "--scale", SCALE, "--tile", 640, "--overlap", 0.2, "--val-frac", 0.0, "--empty-ratio", 0.5)
    assert "warning" not in out, out

    train_lbl = ds / "labels" / "train"
    seen = [0] * len(objs)           # how many tiles contain each original box (even partly)
    complete = [False] * len(objs)   # is each box whole in at least one tile
    for lbl in train_lbl.glob("img_a_x*_y*.txt"):
        stem = lbl.stem
        x0, y0 = int(stem.split("_x")[1].split("_y")[0]), int(stem.split("_y")[1])
        with Image.open(ds / "images" / "train" / f"{stem}.jpg") as im:
            tw, th = im.size
        assert (tw, th) == (640, 640), (stem, tw, th)
        for cx, cy, bw, bh in read_label(lbl):
            # tile label -> original image pixels
            bx1, by1 = (x0 + (cx - bw / 2) * tw) / SCALE, (y0 + (cy - bh / 2) * th) / SCALE
            bx2, by2 = (x0 + (cx + bw / 2) * tw) / SCALE, (y0 + (cy + bh / 2) * th) / SCALE
            match = [i for i, o in enumerate(objs)
                     if bx1 >= o[0] - 1 and by1 >= o[1] - 1 and bx2 <= o[2] + 1 and by2 <= o[3] + 1]
            assert len(match) == 1, f"{stem}: box {bx1:.0f},{by1:.0f},{bx2:.0f},{by2:.0f} matches no original box"
            i = match[0]
            seen[i] += 1
            o = objs[i]
            if abs(bx1 - o[0]) < 1 and abs(by1 - o[1]) < 1 and abs(bx2 - o[2]) < 1 and abs(by2 - o[3]) < 1:
                complete[i] = True
    assert all(complete), f"some boxes never appear whole in a tile: {complete}"
    assert seen[1] >= 2, "a box in the overlap zone should appear in two tiles"
    assert seen[0] >= 1 and seen[2] >= 1 and seen[3] >= 1

    # the box cut at x=640 must NOT be kept in the tile where only a sliver is visible
    for lbl in train_lbl.glob("img_a_x0_y0.txt"):
        assert read_label(lbl) == [] or all(not (b[0] > 0.97) for b in read_label(lbl)), \
            "sliver of a cut box should have been dropped (min-vis)"
    # empty tiles are limited, and img_b (no people) contributes few or none
    n_all = len(list(train_lbl.glob("*.txt")))
    n_pos = sum(1 for p in train_lbl.glob("*.txt") if p.read_text().strip())
    assert n_pos < n_all <= n_pos * 2, (n_pos, n_all)
    print(f"heridal: ok ({n_pos} tiles with people, {n_all - n_pos} empty)")

    # check_dataset passes on clean output, writes previews, and catches a split leak
    out = run("check_dataset.py", ds, "--preview", 2)
    assert out.strip().endswith("OK"), out
    assert list((ds / "_preview").glob("*.jpg"))
    ds2 = tmp / "leaky"
    run("tile_dataset.py", "--images", imgs, "--labels", labels, "--dst", ds2, "--scale", SCALE, "--force-split", "train")
    run("tile_dataset.py", "--images", imgs, "--labels", labels, "--dst", ds2, "--scale", SCALE, "--force-split", "val")
    out = run("check_dataset.py", ds2)
    assert "WARNING" in out and "more than one split" in out, out
    print("check_dataset: ok (clean data passes, leak detected)")


if __name__ == "__main__":
    with tempfile.TemporaryDirectory() as t:
        tmp = Path(t)
        test_visdrone(tmp)
        test_heridal(tmp)
    print("all tests passed")
