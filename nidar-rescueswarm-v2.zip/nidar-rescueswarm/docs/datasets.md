# Datasets

Datasets are not stored in this repo (size, licences). Download them with `data_prep/download_datasets.sh`, then prepare them with the scripts below.

## Plan

| Dataset | Source | Licence | Role | Preparation |
|---|---|---|---|---|
| VisDrone | https://github.com/VisDrone/VisDrone-Dataset | Non-commercial | Stage 1: general drone-view pre-training | Keep pedestrian and people only, map to class 0 |
| HERIDAL | https://zenodo.org/records/5662351 | _check_ | Stage 2: SAR-specific adaptation | VOC xml to YOLO, upscale, tile at 640 |
| Own footage | Our drone, 15 / 25 / 30 m | Ours | **Test set only** | Label as class 0, never trained on |
| SARD | Kaggle: nikolasgegenava/sard-search-and-rescue | _check_ | Optional later stage | Not used for now |

Training order and settings follow the AlienSight preprint (VisDrone, then HERIDAL, tested on separate own footage). See `training/train_stages.sh`.

## Rules

- One class: `0 = person`.
- Split by source image or flight, never at random per tile or frame. `tile_dataset.py` splits by source image, and `check_dataset.py` warns about leaks.
- The test set is fixed before training and never trained on or tuned against.
- Keep a small share of empty images and tiles as negatives (about 10%).

## Preparing the data, step by step

Run each command from the repo root. Paths in `<...>` depend on what your download looks like.

**0. Look at what you downloaded** (do this first, formats differ between versions):

```bash
python data_prep/inspect_dataset.py datasets/raw/visdrone
python data_prep/inspect_dataset.py datasets/raw/heridal
```

**1. VisDrone** (expects the official `images/` and `annotations/` folders):

```bash
python data_prep/convert_visdrone.py --src datasets/raw/visdrone/VisDrone2019-DET-train --dst datasets/visdrone --split train
python data_prep/convert_visdrone.py --src datasets/raw/visdrone/VisDrone2019-DET-val   --dst datasets/visdrone --split val
python data_prep/check_dataset.py datasets/visdrone --preview 20 --imgsz 960
```

**2. HERIDAL labels** (VOC xml to YOLO txt; images stay where they are):

```bash
python data_prep/voc_to_yolo.py --src <heridal train folder> --dst datasets/heridal_labels/train
python data_prep/voc_to_yolo.py --src <heridal test folder>  --dst datasets/heridal_labels/test
```

**3. HERIDAL tiles.** Upscale first because HERIDAL was shot higher than our altitude, then tile. The official test images go into the `test` split through `--force-split`:

```bash
python data_prep/tile_dataset.py --images <heridal train folder> --labels datasets/heridal_labels/train \
    --dst datasets/heridal --scale 1.5 --tile 640 --overlap 0.2 --val-frac 0.1 --prefix heridal_
python data_prep/tile_dataset.py --images <heridal test folder> --labels datasets/heridal_labels/test \
    --dst datasets/heridal --scale 1.5 --tile 640 --overlap 0.2 --force-split test --prefix heridal_
python data_prep/check_dataset.py datasets/heridal --preview 20 --imgsz 640
```

If your HERIDAL images are already small (for example 512 px patches), skip the tiling: use `--scale 1` and a tile size at least as large as the image, or point training at the images directly.

**4. Look at the previews.** Open a few images in `datasets/<name>/_preview/` and check that the boxes sit on people. Check the "under 16px" figure that `check_dataset.py` prints: if most boxes are tiny at your training size, raise `--scale` or `imgsz` before training.

## Settings and why

| Setting | Value | Reason |
|---|---|---|
| Tile size | 640 px | Matches the common training size |
| Overlap | 20% | A person cut by one tile edge is whole in the next |
| Scale | 1.5 | HERIDAL is shot higher than 25 m (check for your copy) |
| Min visible | 40% of a box | Drops slivers that would teach the model to find half-people |
| Empty tiles | about 10% of tiles | Teaches what not to detect without drowning the people |
| Val share | 10%, by source image | No tile of one photo in both train and val |

## Tests

`python tests/test_data_prep.py` runs the scripts on small synthetic data and checks that labels map back to the right pixels. It does not prove the real downloads have the expected format, which is why step 0 comes first.

## Shared converted data

_Add a Kaggle or Drive link here once the converted version exists._
